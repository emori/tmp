# コミュニティ活動に関する調査報告

## 2024/10/28週調査

SONIC公式リポジトリへのNIC様の以下のPRがあり、

https://github.com/sonic-net/sonic-swss/pull/2919

マージ後にCIができないというコメントが上がっている。CIのエラー内容は以下に記載されている。

https://github.com/sonic-net/sonic-swss/pull/2919/checks?check_run_id=31324424340

エラーは３箇所で、いずれもSWSSに関する自動テストでAssetionErrorが発生している。

- test_rebind_eni_route_group
- test_duplicate_eni_route_group
  - `AssertionError: Field SAI_ENI_ATTR_OUTBOUND_ROUTING_GROUP_ID in ASIC_DB table ASIC_STATE:SAI_OBJECT_TYPE_ENI not equal to oid:0x14008000000617`
  - ２つのテストシナリオで同じ内容のAssertionErrorが発生しており、おそらく同一原因と思われる。
- test_PbhRuleUpdate 
  ```
              sai_attr_dict = {
                  "SAI_ACL_ENTRY_ATTR_PRIORITY": self.dvs_acl.get_simple_qualifier_comparator("100"),
                  "SAI_ACL_ENTRY_ATTR_FIELD_ETHER_TYPE": self.dvs_acl.get_simple_qualifier_comparator("34525&mask:0xffff"),
                  "SAI_ACL_ENTRY_ATTR_FIELD_IP_PROTOCOL": self.dvs_acl.get_simple_qualifier_comparator("disabled"),
                  "SAI_ACL_ENTRY_ATTR_FIELD_IPV6_NEXT_HEADER": self.dvs_acl.get_simple_qualifier_comparator("47&mask:0xff"),
                  "SAI_ACL_ENTRY_ATTR_FIELD_GRE_KEY": self.dvs_acl.get_simple_qualifier_comparator("disabled"),
                  "SAI_ACL_ENTRY_ATTR_FIELD_INNER_ETHER_TYPE": self.dvs_acl.get_simple_qualifier_comparator("2048&mask:0xffff"),
                  "SAI_ACL_ENTRY_ATTR_ACTION_SET_ECMP_HASH_ID": self.dvs_acl.get_simple_qualifier_comparator("disabled"),
                  "SAI_ACL_ENTRY_ATTR_ACTION_SET_LAG_HASH_ID": self.dvs_acl.get_simple_qualifier_comparator(hash_id),
                  "SAI_ACL_ENTRY_ATTR_ACTION_COUNTER": self.dvs_acl.get_simple_qualifier_comparator(counter_id)
              }
      
  >           self.dvs_acl.verify_acl_rule_generic(
                  sai_qualifiers=sai_attr_dict
              )
  
  test_pbh.py:339: 
  _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
  
  self = <dvslib.dvs_acl.DVSAcl object at 0x7fb61b24da60>
  sai_qualifiers = {'SAI_ACL_ENTRY_ATTR_ACTION_COUNTER': <function D
  ```

エラー箇所の関数名（verify_acl_rule_generic）から、SAIで実施するACLのルールを生成中になんらかのNGが発生した模様。
なお、SAI_ACL_ENTRY_ATTR_ACTION_COUNTERを指定している箇所が表示されているが、以降のログが欠損しているため、辞書形式でたまたま先頭になっただけで、NG箇所とは限らない。

ログ上では関数から何が返ってきたのか不明なため、関数のコードを調査し、エラーになりそうな箇所を推測中。

## 2024/11/04週調査

test_PbhRuleUpdate のログから起動先のコード内で assert を実施している箇所を抽出。

- ASIC_DB の ASIC_STATE テーブルにある SAI_OBJECT_TYPE_ACL_ENTRY において、以下を検出
  - SAI_ACL_ENTRY_ATTR_TABLE_ID が テーブル先頭のID以外
  - SAI_ACL_ENTRY_ATTR_ADMIN_STATE が true 以外
  - 各属性値が指定したものと不一致
  - 上記以外が設定されている

具体的にどの assert でエラーになったかはログにないため、NIC様が追加したコードに関連する部分で属性の設定に手を加えていないかを確認するか、再現試験を実施して、問題発生時に確認できなかった assert の出力を確認する。

test_rebind_eni_route_group と test_duplicate_eni_route_group については、APP_DB の設定が、ASIC_DB に設定されていないと判断されている模様です。

- test_rebind_eni_route_group の中身
  ```
    dash_db.set_app_db_entry(APP_DASH_ROUTE_GROUP_TABLE_NAME, ROUTE_GROUP1, ROUTE_GROUP1_CONFIG)
    dash_db.set_app_db_entry(APP_DASH_ROUTE_TABLE_NAME, ROUTE_GROUP1, OUTBOUND_ROUTE_PREFIX1, ROUTE_VNET_CONFIG)
  ☆rg1_oid = dash_db.wait_for_asic_db_keys("ASIC_STATE:SAI_OBJECT_TYPE_OUTBOUND_ROUTING_GROUP")[0]
    
    dash_db.set_app_db_entry(APP_DASH_ROUTE_GROUP_TABLE_NAME, ROUTE_GROUP2, ROUTE_GROUP2_CONFIG)
    dash_db.set_app_db_entry(APP_DASH_ROUTE_TABLE_NAME, ROUTE_GROUP2, OUTBOUND_ROUTE_PREFIX1, ROUTE_VNET_CONFIG_UNDERLAY_SIP)
    rg2_oid = dash_db.wait_for_asic_db_keys("ASIC_STATE:SAI_OBJECT_TYPE_OUTBOUND_ROUTING_GROUP", min_keys=2)[1]
    
    dash_db.set_app_db_entry(APP_DASH_ENI_ROUTE_TABLE_NAME, ENI_ID, ENI_ROUTE_GROUP1_CONFIG)
    
    eni_key = dash_db.wait_for_asic_db_keys("ASIC_STATE:SAI_OBJECT_TYPE_ENI")[0]
  ★dash_db.wait_for_asic_db_field("ASIC_STATE:SAI_OBJECT_TYPE_ENI", eni_key, SAI_ENI_ATTR_OUTBOUND_ROUTING_GROUP_ID, rg1_oid)
    
    dash_db.set_app_db_entry(APP_DASH_ENI_ROUTE_TABLE_NAME, ENI_ID, ENI_ROUTE_GROUP2_CONFIG)
    dash_db.wait_for_asic_db_field("ASIC_STATE:SAI_OBJECT_TYPE_ENI", eni_key, SAI_ENI_ATTR_OUTBOUND_ROUTING_GROUP_ID, rg2_oid)
  ```
- test_duplicate_eni_route_group の中身
  ```
    dash_db.set_app_db_entry(APP_DASH_ROUTE_GROUP_TABLE_NAME, ROUTE_GROUP1, ROUTE_GROUP1_CONFIG)
    dash_db.set_app_db_entry(APP_DASH_ROUTE_TABLE_NAME, ROUTE_GROUP1, OUTBOUND_ROUTE_PREFIX1, ROUTE_VNET_CONFIG)
  ☆rg1_oid = dash_db.wait_for_asic_db_keys("ASIC_STATE:SAI_OBJECT_TYPE_OUTBOUND_ROUTING_GROUP")[0]
    
    dash_db.set_app_db_entry(APP_DASH_ENI_ROUTE_TABLE_NAME, ENI_ID, ENI_ROUTE_GROUP1_CONFIG)
    
    eni_key = dash_db.wait_for_asic_db_keys("ASIC_STATE:SAI_OBJECT_TYPE_ENI")[0]
  ★dash_db.wait_for_asic_db_field("ASIC_STATE:SAI_OBJECT_TYPE_ENI", eni_key, SAI_ENI_ATTR_OUTBOUND_ROUTING_GROUP_ID, rg1_oid)
    
    dash_db.set_app_db_entry(APP_DASH_ENI_ROUTE_TABLE_NAME, ENI_ID, ENI_ROUTE_GROUP1_CONFIG)
  ★dash_db.wait_for_asic_db_field("ASIC_STATE:SAI_OBJECT_TYPE_ENI", eni_key, SAI_ENI_ATTR_OUTBOUND_ROUTING_GROUP_ID, rg1_oid)
  ```

NIC様が追加したコードにおいて、APP_DB から ASIC_DB への反映を従来どおり実施しているか確認が必要。

また、NIC様よりご要望を頂いたテストカバレージの不足を回避するテストコードの追加については、該当箇所の直近をとおるテストコードの確認から実施しています。

以下に記載のあるカバレージ不足の箇所を対象に作業中です。

https://dev.azure.com/mssonic/build/_build/results?buildId=687876&view=codecoverage-tab

なお、テストのログでfaildが出ているのが見えるため、テストコードの追加だけでカバレージが100%になるかは不確実です。

```
2024-11-06T07:05:59.4981670Z test_AclRuleIcmp[egress] failed (1 runs remaining out of 2).
2024-11-06T07:05:59.4982588Z 	<class 'AssertionError'>
2024-11-06T07:05:59.4983104Z 	
2024-11-06T07:05:59.4983752Z 	[<TracebackEntry /agent/_work/1/s/tests/test_acl.py:696>, <TracebackEntry /agent/_work/1/s/tests/dvslib/dvs_acl.py:498>, <TracebackEntry /agent/_work/1/s/tests/dvslib/dvs_acl.py:739>]
・・・
2024-11-06T08:00:16.0969470Z test_neighbor_miss[active->ping_serv->standby->resolve_entry->delete_entry-IPv6] failed (1 runs remaining out of 2).
2024-11-06T08:00:16.0970085Z 	<class 'AssertionError'>
2024-11-06T08:00:16.0970780Z 	Expected keys not found: expected=['Vlan1000:fc02:1000::100'], received=[], table="NEIGH_TABLE"
2024-11-06T08:00:16.0971710Z 	[<TracebackEntry /agent/_work/1/s/tests/test_mux.py:1575>, <TracebackEntry /agent/_work/1/s/tests/test_mux.py:1290>, <TracebackEntry /agent/_work/1/s/tests/test_mux.py:1236>, <TracebackEntry /agent/_work/1/s/tests/dvslib/dvs_database.py:451>]
・・・
2024-11-06T08:01:16.7987795Z test_offload[enabled] failed (1 runs remaining out of 2).
2024-11-06T08:01:16.7988265Z 	<class 'KeyError'>
2024-11-06T08:01:16.7988549Z 	'1.1.1.0/24'
2024-11-06T08:01:16.7990380Z 	[<TracebackEntry /agent/_work/1/s/tests/test_route.py:1101>, <TracebackEntry /agent/_work/1/s/tests/test_route.py:1075>]
```

最初のACLは既に調査に着手していた AssertionError かと思われますが、残り２つは別の問題かもしれません。

## 2024/11/11週調査

以下に記載のあるカバレージ不足の箇所を対象に作業中です。

https://dev.azure.com/mssonic/build/_build/results?buildId=687876&view=codecoverage-tab

- fmsyncd/fpmlink.cpp
  - 282行目
    - tests/mock_test/fpmsyncd/test_fpmlink.cppにTEST_F()を追加
      - メッセージ種別をRTM_NEWROUTE（0x19）からRTM_DELNEXTHOP（0x69）に変更
- fmsyncd/routesync.cpp
  - 596～598行目
    - tests/mock_test/test_routesync.cppにTEST_F()を追加
      - onMsgRaw()起動直前にメッセージ種別をRTM_MAXに変更
  - 604行目
    - tests/mock_test/test_routesync.cppにTEST_F()を追加
      - onMsgRaw()起動直前にメッセージ種別をRTM_DELNEXTHOPに変更
  - 621行目
    - 604行目と同じTEST_F()
  - 791行目
    - 該当箇所を含むMOCK起動（EXPECT_CALL(m_mock, onMsg(_, _))）を定義する既存テストコードはtests/mock_test/test_routesync.cppにある事を確認
    - 該当箇所に分岐するためにはrtnl_route_get_nh_id()で0以外の値を返却する必要がある
      ```
      uint32_t nhg_id = rtnl_route_get_nh_id(route_obj);
      if(nhg_id)
      {
          ★ const auto itg = m_nh_groups.find(nhg_id);
      ```
      - libnlのマニュアルにrtnl_route_get_nh_id()が見当たらない
      - NextHopのメッセージヘッダから値を取得する関数と思われるため、この前提で既存テストコードが関数から0を返却している理由を確認中
        - 関数が未実装のため0を返却しているという事であれば該当箇所の通過は不可能なため、諦める必要がある

## 2024/11/18週調査

以下に記載のあるカバレージ不足の箇所を対象に作業中です。

https://dev.azure.com/mssonic/build/_build/results?buildId=687876&view=codecoverage-tab

- fmsyncd/routesync.cpp
  - 791行目
    - コードを見つけられなかったrtnl_route_get_nh_id()がSONiC/buildimageのパッチ内にある事を確認
    - 同じパッチ内にあるrtnl_route_set_nh_id()をテストコードで使用する事で、未到達ルートに分岐させる
  - その他
    - 上記と類似の経路を通る分岐について、テストコードを順次作成
    - 作業中にGitHubにカバレージ不足が記載されたページが削除されたため、対象範囲がわからなくなった
    - 再度のCI実行をNIC様に依頼したが、実施不可との連絡があった
　　- （カバレージ到達済みかもしれないが手の付けやすい）11箇所まで分岐をつぶした時点で作業を中断
